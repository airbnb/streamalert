SDK_VALUE_NOT_SET = object()
