# coding: utf-8
from __future__ import unicode_literals
from .base_object import BaseObject


class DevicePinner(BaseObject):
    """Represents the device pinner"""

    _item_type = 'device_pinner'
