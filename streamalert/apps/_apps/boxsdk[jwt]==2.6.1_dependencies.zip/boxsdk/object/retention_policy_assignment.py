# coding: utf-8
from __future__ import unicode_literals, absolute_import
from .base_object import BaseObject


class RetentionPolicyAssignment(BaseObject):
    """Represents a Box retention policy assignment."""
    _item_type = 'retention_policy_assignment'
