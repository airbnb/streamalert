# coding: utf-8

from __future__ import unicode_literals, absolute_import


__version__ = '2.6.1'
