# coding: utf-8

from __future__ import unicode_literals
# pylint:disable=unused-import, import-error
try:
    from collections import OrderedDict
except ImportError:
    from ordereddict import OrderedDict
